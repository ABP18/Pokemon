<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PokeController;
use App\Http\Controllers\UserController;


//damos el acceso al controlador de tareas
Route::resource('Pokemon', PokeController::class);

//damos el acceso al controlador de tareas
Route::resource('User', UserController::class);

//damos el acceso al controlador de tareas
Route::post('/login', [UserController::class, 'login'])->middleware('checkUserExistence')->name('User.login');

//damos el acceso al controlador de tareas
Route::get('/pokemon/indexUser', [PokeController::class, 'indexUser'])->name('Pokemon.indexUser');
