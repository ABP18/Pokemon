@section('content')
    <div class="container">
        <a href="{{ route('Pokemon.create') }}" class="btn btn-primary mb-3">Insertar Pokemon</a>

        <table class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Tipo</th>
                    <th>Tamaño</th>
                    <th>Peso</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($pokemons as $pokemon)
                    <tr>
                        <td>{{ $pokemon->id }}</td>
                        <td>{{ $pokemon->nombre }}</td>
                        <td>{{ $pokemon->tipo }}</td>
                        <td>{{ $pokemon->tamaño }}</td>
                        <td>{{ $pokemon->peso }}</td>
                        <td>
                            <a href="{{ route('Pokemon.edit', $pokemon->id) }}" class="btn btn-warning btn-sm">Editar</a>
                            <a href="{{ route('Pokemon.destroy', $pokemon->id) }}" onclick="event.preventDefault(); document.getElementById('delete-form-{{ $pokemon->id }}').submit();" class="btn btn-danger btn-sm">Eliminar</a>
                            <form id="delete-form-{{ $pokemon->id }}" action="{{ route('Pokemon.destroy', $pokemon->id) }}" method="POST" style="display: none;">
                                @csrf
                                @method('DELETE')
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>