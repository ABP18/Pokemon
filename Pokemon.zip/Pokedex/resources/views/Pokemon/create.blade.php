@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <h1">Create Pokemon</h1>

                <div class="card-body">
                    <form method="POST" action="{{ route('Pokemon.store') }}">
                        @csrf

                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" name="nombre" id="nombre" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="tipo">Tipo</label>
                            <select name="tipo" id="tipo" class="form-control" required>
                                <option value="agua">Agua</option>
                                <option value="fuego">Fuego</option>
                                <option value="planta">Planta</option>
                                <option value="roca">Roca</option>
                                <option value="electrico">Eléctrico</option>
                                <option value="anticipacion">Anticipacion</option>
                            </select>
                        </div>


                        <div class="form-group">
                            <label for="tamaño">Tamaño</label>
                            <select name="tamaño" id="tamaño" class="form-control" required>
                                <option value="pequeño">pequeño</option>
                                <option value="mediano">mediano</option>
                                <option value="grande">grande</option>
                            </select>
                        </div>


                        <div class="form-group">
                            <label for="peso">Peso</label>
                            <input type="number" name="peso" id="peso" class="form-control" required>
                        </div>

                        <button type="submit" class="btn btn-primary">Guardar Pokemon</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


