<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PokeController;


//damos el acceso al controlador de tareas
Route::resource('Pokemon', PokeController::class);
