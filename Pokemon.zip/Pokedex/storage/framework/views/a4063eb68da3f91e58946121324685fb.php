<?php $__env->startSection('content'); ?>
    <div class="container">
        <a href="<?php echo e(route('Pokemon.create')); ?>" class="btn btn-primary mb-3">Insertar Pokemon</a>

        <table class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Tipo</th>
                    <th>Tamaño</th>
                    <th>Peso</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pokemon->id); ?></td>
                        <td><?php echo e($pokemon->nombre); ?></td>
                        <td><?php echo e($pokemon->tipo); ?></td>
                        <td><?php echo e($pokemon->tamaño); ?></td>
                        <td><?php echo e($pokemon->peso); ?></td>
                        <td>
                            <a href="<?php echo e(route('Pokemon.edit', $pokemon->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
                            <a href="<?php echo e(route('Pokemon.destroy', $pokemon->id)); ?>" onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($pokemon->id); ?>').submit();" class="btn btn-danger btn-sm">Eliminar</a>
                            <form id="delete-form-<?php echo e($pokemon->id); ?>" action="<?php echo e(route('Pokemon.destroy', $pokemon->id)); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div><?php /**PATH C:\xampp\htdocs\Pokedex\resources\views/Pokemon/index.blade.php ENDPATH**/ ?>