                    <?php $__env->startSection('content'); ?>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-md-8">
                                <div class="card">
                                    <h1">Editar Pokemon</h1>

                                    <div class="card-body">
                                    <form method="POST" action="<?php echo e(route('Pokemon.update', $pokemon->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" name="nombre" id="nombre" class="form-control" value="<?php echo e($pokemon->nombre); ?>" required>
                        </div>

                            <div class="form-group">
                            <label for="tipo">Tipo</label>
                            <select name="tipo" id="tipo" class="form-control" required>
                                <option value="agua" <?php echo e($pokemon->tipo == 'agua' ? 'selected' : ''); ?>>Agua</option>
                                <option value="fuego" <?php echo e($pokemon->tipo == 'fuego' ? 'selected' : ''); ?>>Fuego</option>
                                <option value="planta" <?php echo e($pokemon->tipo == 'planta' ? 'selected' : ''); ?>>Fuego</option>
                                <option value="roca" <?php echo e($pokemon->tipo == 'roca' ? 'selected' : ''); ?>>Roca</option>
                                <option value="electrico" <?php echo e($pokemon->tipo == 'electrico' ? 'selected' : ''); ?>>electrico</option>
                                <option value="anticipacion" <?php echo e($pokemon->tipo == 'anticipacion' ? 'selected' : ''); ?>>anticipacion</option>

                            </select>
                        </div>


                            <div class="form-group">
                                <label for="tamaño">Tamaño</label>
                                <select name="tamaño" id="tamaño" class="form-control" required>
                                    <option value="pequeño" <?php echo e($pokemon->tamaño == 'pequeño' ? 'selected' : ''); ?>>Pequeño</option>
                                    <option value="mediano" <?php echo e($pokemon->tamaño == 'mediano' ? 'selected' : ''); ?>>Mediano</option>
                                    <option value="grande" <?php echo e($pokemon->tamaño == 'grande' ? 'selected' : ''); ?>>Grande</option>
                                </select>
                            </div>


                        <div class="form-group">
                            <label for="peso">Peso</label>
                            <input type="number" name="peso" id="peso" class="form-control" value="<?php echo e($pokemon->peso); ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Actualizar Pokemon</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\Pokedex\resources\views/Pokemon/edit.blade.php ENDPATH**/ ?>