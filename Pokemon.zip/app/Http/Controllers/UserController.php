<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use App\Models\UserModel;

class UserController extends Controller
{
    public function index()
    {
        $usuarios = UserModel::all();
        return view('User.index', ['usuarios' => $usuarios]); 
    }

    public function create()
    {
        return view('User.create'); 

    }

    public function edit(Request $request)
    {
        return view('User.edit'); 

    }

    public function destroy(){}

    public function update(){}
    


    public function store(Request $request)
    {
        $request->validate([
            'user' => 'required|max:255',
            'passw' => 'required|max:255',
            'rol' => 'required',
        ]);

        // Crear un nuevo usuario sin buscar por ID
        $usertarea = new UserModel([
            'user' => $request->input('user'),
            'passw' => $request->input('passw'),
            'rol' => $request->input('rol'),
        ]);

        $usertarea->save(); // Guardar el nuevo usuario

       // return 'Se ha creado correctamente';
        // Puedes redirigir a la vista de índice si lo deseas:
        return redirect()->route('User.login');
    }
    public function login(Request $request): RedirectResponse
    {
        $user = UserModel::where('user', $request->input('user'))->first();
    
        if ($user) {
            // Lógica de inicio de sesión si el usuario existe
    
            // Redirigir según el rol del usuario
            if ($user->rol === 'admin') {
                // Redireccionar a la ruta Pokemon.index si el usuario es Admin
                return redirect()->route('Pokemon.index')->with('success', '¡Bienvenido, Admin! Has iniciado sesión correctamente.');
            } elseif ($user->rol === 'user') {
                // Redireccionar a la ruta User.indexUser si el usuario es User
                return redirect()->route('Pokemon.indexUser')->with('success', '¡Bienvenido, Usuario! Has iniciado sesión correctamente.');
            }
        }
            
        // Redireccionar a la vista de inicio de sesión con el mensaje de error
        return redirect()->route('User.create')->with('error', 'El usuario no existe en la base de datos.');
    }
    
}
