<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PokeModel;

class PokeController extends Controller
{
    //

    public function index()
    {
        // Muestra la lista de tareas
        $pokemons = PokeModel::all();
        return view ('Pokemon.index',compact('pokemons')); 
    }
    public function indexUser()
    {
        // Muestra la lista de tareas
        $pokemons = PokeModel::all();
        return view ('Pokemon.indexUser',compact('pokemons')); 
    }
    public function create()
    {
        // Muestra el formulario para crear una nueva tarea
        return view('Pokemon.create');
    }

    public function edit($id)
    {
        $pokemon = PokeModel::findOrFail($id);
        return view('Pokemon.edit', compact('pokemon'));
    }

    public function destroy($id)
{
    $pokemon = PokeModel::findOrFail($id);
    $pokemon->delete();

    return redirect()->route('Pokemon.index');
}

    public function update(Request $request, $id)
    {
        $request->validate([
            'nombre' => 'required|max:255',
            'tipo' => 'required|max:255',
            'tamaño' => 'nullable',
            'peso' => 'nullable',
        ]);
    
        $pokemon = PokeModel::findOrFail($id);
        $pokemon->update($request->all());
    
        return redirect()->route('Pokemon.index');
    }
    

    public function store(Request $request)
    {
        // Almacena una nueva tarea en la base de datos
          // Validación de datos
          $request->validate([
            'nombre' => 'required|max:255',
            'tipo' => 'required|max:255',
            'tamaño' => 'nullable',
            'peso' => 'nullable',
        ]);

        // Crear una nueva instancia de Tarea con los datos del formulario
        $poketarea = new PokeModel([
            'nombre' => $request->input('nombre'),
            'tipo' => $request->input('tipo'),
            'tamaño' => $request->input('tamaño'),
            'peso' => $request->input('peso'),
        ]);


        PokeModel::create($request->all());
        return redirect()->route ('Pokemon.index');
  }

}
