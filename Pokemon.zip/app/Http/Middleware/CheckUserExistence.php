<?php

namespace App\Http\Middleware;

use Closure;
use App\Models\UserModel;

class CheckUserExistence
{
    public function handle($request, Closure $next)
    {
        $user = UserModel::where('user', $request->input('user'))->first();

        if (!$user) {
            return redirect()->route('User.create')->with('error', 'El usuario no existe en la base de datos.');
        }

        return $next($request);
    }
}
