<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB; //libreria nos permite hacer insert
use Illuminate\Support\Str; //liberaria para funciones str

class PokemonSeed extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //inserta 10 pokemons
        for($i =0; $i<=9; $i++)
        {
            $tipos = ["agua", "fuego", "planta", "roca", "electrico", "anticipacion"];
            $tamaños = ["pequeño", "mediano", "grande"];
            
// Leer el contenido del archivo de texto
$nombresArchivo = file_get_contents('pokemon.txt');

// Eliminar las comillas dobles y dividir los nombres en un array
$nombresArray = explode(',', str_replace('"', '', $nombresArchivo));

// Seleccionar un nombre aleatorio
$nombreAleatorio = $nombresArray[array_rand($nombresArray)];

// Insertar en la base de datos
DB::table('pokemon')->insert([
    'id' => '0',
    'nombre' => $nombreAleatorio,
    'tipo' => $tipos[array_rand($tipos)],
    'tamaño' => $tamaños[array_rand($tamaños)],
    'peso' => rand(1,100),
]);
            
        }
    }
}
