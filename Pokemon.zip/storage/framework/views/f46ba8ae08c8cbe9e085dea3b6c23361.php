
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <h1>Crear Usuario</h1>
                    <form method="POST" action="<?php echo e(route('User.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="user">Nombre Usuario</label>
                            <input type="text" name="user" id="user" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="passw">Contraseña</label>
                            <input type="text" name="passw" id="passw" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="rol">Tipo</label>
                            <select name="rol" id="rol" class="form-control" required>
                                <option value="admin">Admin</option>
                                <option value="user">Usuario</option>
                            </select>
                        </div>

                        <button type="submit" class="btn btn-primary">Crear Usuario</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Biau\Pokemon\Pokedex\resources\views/User/index.blade.php ENDPATH**/ ?>