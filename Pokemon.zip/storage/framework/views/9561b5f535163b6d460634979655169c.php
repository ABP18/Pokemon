
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <h1>Iniciar Sesion</h1>
                    <form method="POST" action="<?php echo e(route('User.login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="user">Nombre Usuario</label>
                            <input type="text" name="user" id="user" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="passw">Contraseña</label>
                            <input type="text" name="passw" id="passw" class="form-control" required>
                        </div>

                        <button type="submit" class="btn btn-primary">Iniciar Sesion</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php if(session('error')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\Pokedex\resources\views/User/create.blade.php ENDPATH**/ ?>