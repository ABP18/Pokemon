<?php $__env->startSection('content'); ?>
    <div class="container">

        <table class="table table-striped table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Tipo</th>
                    <th>Tamaño</th>
                    <th>Peso</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pokemon->id); ?></td>
                        <td><?php echo e($pokemon->nombre); ?></td>
                        <td><?php echo e($pokemon->tipo); ?></td>
                        <td><?php echo e($pokemon->tamaño); ?></td>
                        <td><?php echo e($pokemon->peso); ?></td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div><?php /**PATH C:\xampp\htdocs\Pokedex\resources\views/Pokemon/indexUser.blade.php ENDPATH**/ ?>