                    @section('content')
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-md-8">
                                <div class="card">
                                    <h1">Editar Pokemon</h1>

                                    <div class="card-body">
                                    <form method="POST" action="{{ route('Pokemon.update', $pokemon->id) }}">
                        @csrf
                        @method('PUT')

                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" name="nombre" id="nombre" class="form-control" value="{{ $pokemon->nombre }}" required>
                        </div>

                            <div class="form-group">
                            <label for="tipo">Tipo</label>
                            <select name="tipo" id="tipo" class="form-control" required>
                                <option value="agua" {{ $pokemon->tipo == 'agua' ? 'selected' : '' }}>Agua</option>
                                <option value="fuego" {{ $pokemon->tipo == 'fuego' ? 'selected' : '' }}>Fuego</option>
                                <option value="planta" {{ $pokemon->tipo == 'planta' ? 'selected' : '' }}>Fuego</option>
                                <option value="roca" {{ $pokemon->tipo == 'roca' ? 'selected' : '' }}>Roca</option>
                                <option value="electrico" {{ $pokemon->tipo == 'electrico' ? 'selected' : '' }}>electrico</option>
                                <option value="anticipacion" {{ $pokemon->tipo == 'anticipacion' ? 'selected' : '' }}>anticipacion</option>

                            </select>
                        </div>


                            <div class="form-group">
                                <label for="tamaño">Tamaño</label>
                                <select name="tamaño" id="tamaño" class="form-control" required>
                                    <option value="pequeño" {{ $pokemon->tamaño == 'pequeño' ? 'selected' : '' }}>Pequeño</option>
                                    <option value="mediano" {{ $pokemon->tamaño == 'mediano' ? 'selected' : '' }}>Mediano</option>
                                    <option value="grande" {{ $pokemon->tamaño == 'grande' ? 'selected' : '' }}>Grande</option>
                                </select>
                            </div>


                        <div class="form-group">
                            <label for="peso">Peso</label>
                            <input type="number" name="peso" id="peso" class="form-control" value="{{ $pokemon->peso }}" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Actualizar Pokemon</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


