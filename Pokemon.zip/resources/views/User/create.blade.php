
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <h1>Iniciar Sesion</h1>
                    <form method="POST" action="{{ route('User.login') }}">
                        @csrf
                        <div class="form-group">
                            <label for="user">Nombre Usuario</label>
                            <input type="text" name="user" id="user" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="passw">Contraseña</label>
                            <input type="text" name="passw" id="passw" class="form-control" required>
                        </div>

                        <button type="submit" class="btn btn-primary">Iniciar Sesion</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@if(session('error'))
    <div class="alert alert-danger" role="alert">
        {{ session('error') }}
    </div>
@endif

@if(session('success'))
    <div class="alert alert-success" role="alert">
        {{ session('success') }}
    </div>
@endif

